@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONFIGURAR-CONEXAO.ps1"
if errorlevel 1 (
  echo.
  echo Nao foi possivel concluir. Confira a mensagem acima.
  pause
)
