# Le dados da conexao guardados apenas no perfil do Windows do usuario.
$ErrorActionPreference = 'Stop'
$base = Join-Path $env:LOCALAPPDATA 'SaborFlow\Impressao'
$config = Get-Content -Raw -LiteralPath (Join-Path $base 'config.json') | ConvertFrom-Json
$secret = Get-Content -Raw -LiteralPath (Join-Path $base 'token.dpapi')
$secure = ConvertTo-SecureString -String $secret.Trim()
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
$agent = Join-Path $base 'INICIAR-IMPRESSAO-AUTOMATICA.ps1'
if (-not (Test-Path -LiteralPath $agent)) { throw 'Agente nao encontrado no computador.' }
& $agent -ServerUrl ([string]$config.ServerUrl) -Token $token
