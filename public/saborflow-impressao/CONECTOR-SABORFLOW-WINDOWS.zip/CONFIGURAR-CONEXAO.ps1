# Instalador do conector local do SaborFlow - executado no Windows da loja.
# O token e protegido com DPAPI do usuario Windows atual. Nunca sera enviado ao GitHub.
$ErrorActionPreference = 'Stop'
$agent = Join-Path $PSScriptRoot 'INICIAR-IMPRESSAO-AUTOMATICA.ps1'
if (-not (Test-Path -LiteralPath $agent)) { throw 'Arquivo do agente de impressao nao encontrado neste ZIP.' }
Write-Host 'SABORFLOW - CONEXAO DA IMPRESSORA' -ForegroundColor Cyan
Write-Host 'Este computador deve estar ligado e ter a impressora instalada no Windows.'
try { Get-Printer | Select-Object Name, PortName | Format-Table -AutoSize } catch {
  Write-Warning 'Nao foi possivel listar as impressoras. Confira o driver no Windows.'
}
$url = (Read-Host 'Cole o endereco HTTPS do SaborFlow (sem / no fim)').Trim().TrimEnd('/')
$parsed = $null
if (-not [Uri]::TryCreate($url, [UriKind]::Absolute, [ref]$parsed) -or $parsed.Scheme -ne 'https') {
  throw 'Informe um endereço HTTPS valido do SaborFlow.'
}
$secure = Read-Host 'Cole o token gerado no painel do SaborFlow (nao sera exibido)' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
if ($token -notmatch '^sfpa_[a-zA-Z0-9_-]{30,}$') { throw 'Token invalido. Gere uma nova conexao no painel.' }
Write-Host 'Validando a conexao com o servidor...' -ForegroundColor Gray
try {
  $probe = Invoke-RestMethod -Uri "$url/api/print-queue" -Headers @{ 'x-print-token' = $token; 'x-saborflow-print-version' = '2' } -Method Get -TimeoutSec 20
  if (-not $probe.organization.name) { throw 'Servidor nao retornou a empresa.' }
} catch { throw "Conexao nao validada. Nada foi instalado. $($_.Exception.Message)" }
$base = Join-Path $env:LOCALAPPDATA 'SaborFlow\Impressao'
New-Item -ItemType Directory -Path $base -Force | Out-Null
Copy-Item -LiteralPath $agent -Destination (Join-Path $base 'INICIAR-IMPRESSAO-AUTOMATICA.ps1') -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'INICIAR-SALVO.ps1') -Destination (Join-Path $base 'INICIAR-SALVO.ps1') -Force
@{ ServerUrl = $url } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'config.json') -Encoding UTF8
$secure | ConvertFrom-SecureString | Set-Content -LiteralPath (Join-Path $base 'token.dpapi') -Encoding ASCII
$token = $null
$startup = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startup 'SaborFlow Impressao.lnk'
try {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = "$PSHOME\powershell.exe"
  $shortcut.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $base 'INICIAR-SALVO.ps1')`""
  $shortcut.WorkingDirectory = $base
  $shortcut.Save()
  Write-Host 'Inicio automatico ao entrar no Windows: ATIVADO' -ForegroundColor Green
} catch {
  Write-Warning 'Nao foi possivel criar inicio automatico. Abra INICIAR-SALVO.ps1 no seu Windows quando ligar a loja.'
}
Write-Host "Empresa: $($probe.organization.name)" -ForegroundColor Green
Write-Host 'Conexao verificada. O agente sera iniciado agora.' -ForegroundColor Green
Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$(Join-Path $base 'INICIAR-SALVO.ps1')`"") -WorkingDirectory $base
Write-Host 'Volte ao painel Conectar servicos > Impressora, clique Atualizar computadores e escolha a impressora.' -ForegroundColor Yellow
